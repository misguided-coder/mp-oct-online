package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Outgoing;

@ApplicationScoped
public class AuctionProducerService {

	List<String> list = Arrays.asList("BMW X7", "BMW X2", "Merc 400D", "Jaguar XE", "Toyota Fornuter");

	@Outgoing("Auctions")
	public String newAuction() {
		System.out.println("Auction Created!!");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int idx = (int) (Math.floor(Math.random() * list.size()));
		return list.get(idx);
	}

}
