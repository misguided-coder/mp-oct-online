package com.example;

import java.util.HashSet;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonObject;
import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value = "/auctions", decoders = { MessageDecoder.class }, encoders = { MessageEncoder.class })
public class AuctionMS {

	static Set<Session> clientSessions = new HashSet<>();

	public static void sendMessageToAll(JsonObject message) {
		for (Session session : clientSessions) {
			try {
				session.getBasicRemote().sendObject(message);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@OnOpen
	public void onOpen(Session session) {
		System.out.println("WebSocket opened for =====> " + session.getId());
		clientSessions.add(session);
	}

	@OnMessage
	public void onMessage(String message, Session session) {
		System.out.println("Message received : " + message + " from ======> " + session.getId());
		try {
			JsonObject auction = Json.createObjectBuilder().add("item", message).add("price", 600000.00).build();
			session.getBasicRemote().sendObject(auction);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@OnError
	public void onError(Session session, Throwable throwable) {
		System.out.println("WebSocket error for =====> " + session.getId() + " ======>  " + throwable.getMessage());
	}


	@OnClose
	public void onClose(Session session, CloseReason closeReason) {
		System.out.println("WebSocket closed for  ======> " + session.getId() + " with reason  ======> " + closeReason.getCloseCode());
		clientSessions.remove(session);
	}
}