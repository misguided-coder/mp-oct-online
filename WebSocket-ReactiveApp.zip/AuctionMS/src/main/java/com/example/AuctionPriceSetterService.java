package com.example;

import javax.enterprise.context.ApplicationScoped;
import javax.json.Json;
import javax.json.JsonObject;

import org.eclipse.microprofile.reactive.messaging.Incoming;

@ApplicationScoped
public class AuctionPriceSetterService {

	@Incoming("Auctions")
	public void setPriceForAuction(String auction) {
		System.out.println("Auction Item Price Set!!");
		
		JsonObject message = Json.createObjectBuilder().add("item", auction).add("price",(Math.round(Math.random() * 8000000.00)))
				.build();

		AuctionMS.sendMessageToAll(message);	
	}
}
