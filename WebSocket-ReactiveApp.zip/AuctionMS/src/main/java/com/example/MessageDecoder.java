package com.example;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

public class MessageDecoder implements Decoder.Text<JsonObject> {

	@Override
	public JsonObject decode(String message) throws DecodeException {
		try (JsonReader jsonReader = Json.createReader(new StringReader(message))) {
			return jsonReader.readObject();
		}
	}

	@Override
	public boolean willDecode(String message) {
		return true;
	}

	@Override
	public void init(EndpointConfig config) {
	}

	@Override
	public void destroy() {
	}
}