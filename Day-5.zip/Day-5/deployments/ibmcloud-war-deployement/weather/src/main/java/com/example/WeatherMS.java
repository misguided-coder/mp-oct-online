package com.example;

import java.time.LocalDate;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@ApplicationScoped
@Path("/weather")
public class WeatherMS {

	@Path("/info")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String info() {
		System.out.println("INFO ==========> Inside WeatherMS.info()!!!!!");
		return "Weather is Cool on " + LocalDate.now();
	}
}
